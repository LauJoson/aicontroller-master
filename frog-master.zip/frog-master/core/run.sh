mvn clean package
java -jar target/frog-*.jar
